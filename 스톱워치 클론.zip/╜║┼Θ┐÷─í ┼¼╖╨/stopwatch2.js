let min = 0;
let sec = 0;
let ten = 0;

const timerMin = document.getElementById("min");
const timerSec = document.getElementById("sec");
const timerTen = document.getElementById("ten");
const btnStart = document.getElementById("star_btn");
const BtnStop = document.getElementById("stop_btn");
const BtnReset = document.getElementById("reset_btn");

btnStart.onclick = function() {
    setInterval(operateTimer,10)
} 

function operateTimer(){
    ten++;
    appendTens.textContent = ten
}